//print the  maximum and minmum in an array//
#include <stdio.h>

int main() {
    int my_array[] = {3, 5, 2, 8, 1};
    int array_size = sizeof(my_array) / sizeof(my_array[0]);
    int max_value = my_array[0];
    int min_value = my_array[0];

   
    for (int i = 1; i < array_size; i++) {
        if (my_array[i] > max_value) {
            max_value = my_array[i];
        }
        if (my_array[i] < min_value) {
            min_value = my_array[i];
        }
    }

    printf("Maximum value: %d\n", max_value);
    printf("Minimum value: %d\n", min_value);

    return 0;
}
 