#include <stdio.h>
#include <string.h>

#define MAX_NAMES 50
#define MAX_NAME_LENGTH 30

int main() {
    char names[MAX_NAMES][MAX_NAME_LENGTH];
    int i, j, n;
    char temp[MAX_NAME_LENGTH];

    printf("Enter the number of names: ");
    scanf("%d", &n);

    
    printf("Enter the names:\n");
    for (i = 0; i < n; i++) {
        scanf("%s", names[i]);
    }

   
    for (i = 0; i < n-1; i++) {
        for (j = 0; j < n-i-1; j++) {
            if (strcmp(names[j], names[j+1]) > 0) {
                strcpy(temp, names[j]);
                strcpy(names[j], names[j+1]);
                strcpy(names[j+1], temp);
            }
        }
    }

    
    printf("The sorted names are:\n");
    for (i = 0; i < n; i++) {
        printf("%s\n", names[i]);
    }

    return 0;
}
